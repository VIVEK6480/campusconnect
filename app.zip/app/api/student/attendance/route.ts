import { NextRequest, NextResponse } from "next/server";
import jwt, { JwtPayload } from "jsonwebtoken";
import { prisma } from "@/lib/prisma";

type TokenPayload = JwtPayload & {
  id?: string;
  userId?: string;
  studentId?: string;
  role?: string;
};

function getLoggedInStudentId(request: NextRequest): string | null {
  const token = request.cookies.get("token")?.value;
  if (!token || !process.env.JWT_SECRET) return null;

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET) as TokenPayload;
    const role = String(decoded.role ?? "").toUpperCase();

    if (role && role !== "STUDENT") return null;

    return (
      (typeof decoded.id === "string" && decoded.id) ||
      (typeof decoded.userId === "string" && decoded.userId) ||
      (typeof decoded.studentId === "string" && decoded.studentId) ||
      (typeof decoded.sub === "string" && decoded.sub) ||
      null
    );
  } catch {
    return null;
  }
}

function normalizeStatus(status: unknown): string {
  return String(status ?? "").trim().toUpperCase();
}

function isPresent(status: unknown): boolean {
  return normalizeStatus(status) === "PRESENT";
}

function isAbsent(status: unknown): boolean {
  return normalizeStatus(status) === "ABSENT";
}

function percentage(present: number, total: number): number {
  return total > 0 ? Math.round((present / total) * 100) : 0;
}

export async function GET(request: NextRequest) {
  try {
    const studentId = getLoggedInStudentId(request);

    if (!studentId) {
      return NextResponse.json(
        { success: false, message: "Student authentication is required." },
        { status: 401 }
      );
    }

    const student = await prisma.user.findUnique({
      where: { id: studentId },
      select: {
        id: true,
        campusUserId: true,
        name: true,
        email: true,
        profileImage: true,
        role: true,
        approvalStatus: true,
      },
    });

    if (!student) {
      return NextResponse.json(
        { success: false, message: "Student account not found." },
        { status: 404 }
      );
    }

    if (String(student.role).toUpperCase() !== "STUDENT") {
      return NextResponse.json(
        { success: false, message: "Only students can access this attendance page." },
        { status: 403 }
      );
    }

    const registrations = await prisma.studentRegistration.findMany({
      where: { studentId: student.id },
      select: {
        id: true,
        studentId: true,
        subjectId: true,
        semester: true,
        section: true,
        subject: {
          select: { id: true, name: true, semester: true },
        },
      },
      orderBy: [
        { semester: "asc" },
        { subject: { name: "asc" } },
      ],
    });

    const registeredKeys = new Set(
      registrations.map((registration) =>
        [
          registration.subjectId,
          registration.semester,
          registration.section.trim().toUpperCase(),
        ].join("|")
      )
    );

    const registeredSubjectIds = Array.from(
      new Set(registrations.map((registration) => registration.subjectId))
    );

    const [classAttendance, eventAttendance] = await Promise.all([
      registeredSubjectIds.length > 0
        ? prisma.classAttendance.findMany({
            where: {
              studentId: student.id,
              subjectId: { in: registeredSubjectIds },
            },
            select: {
              id: true,
              sessionId: true,
              studentId: true,
              subjectId: true,
              status: true,
              markedAt: true,
              updatedAt: true,
              subject: {
                select: { id: true, name: true, semester: true },
              },
              session: {
                select: {
                  id: true,
                  facultyId: true,
                  subjectId: true,
                  semester: true,
                  section: true,
                  sessionDate: true,
                  createdAt: true,
                },
              },
            },
            orderBy: [
              { session: { sessionDate: "desc" } },
              { markedAt: "desc" },
            ],
          })
        : [],

      prisma.attendance.findMany({
        where: { userId: student.id },
        select: {
          id: true,
          userId: true,
          eventId: true,
          status: true,
          markedAt: true,
          updatedAt: true,
          event: {
            select: {
              id: true,
              title: true,
              description: true,
              venue: true,
              eventDate: true,
              image: true,
              club: {
                select: { id: true, name: true, logo: true },
              },
            },
          },
        },
        orderBy: { markedAt: "desc" },
      }),
    ]);

    const validClassAttendance = classAttendance.filter((record) => {
      if (!record.session) return false;

      const key = [
        record.subjectId,
        record.session.semester,
        record.session.section.trim().toUpperCase(),
      ].join("|");

      return registeredKeys.has(key);
    });

    const subjects = registrations.map((registration) => {
      const records = validClassAttendance.filter(
        (record) =>
          record.subjectId === registration.subjectId &&
          record.session.semester === registration.semester &&
          record.session.section.trim().toUpperCase() ===
            registration.section.trim().toUpperCase()
      );

      const present = records.filter((record) => isPresent(record.status)).length;
      const absent = records.filter((record) => isAbsent(record.status)).length;

      return {
        registrationId: registration.id,
        subjectId: registration.subjectId,
        subjectName: registration.subject.name,
        semester: registration.semester,
        section: registration.section,
        present,
        absent,
        total: records.length,
        percentage: percentage(present, records.length),
        records: records.map((record) => ({
          id: record.id,
          status: record.status,
          markedAt: record.markedAt,
          updatedAt: record.updatedAt,
          date: record.session.sessionDate,
          session: {
            id: record.session.id,
            sessionDate: record.session.sessionDate,
            semester: record.session.semester,
            section: record.session.section,
          },
          subject: {
            id: record.subject.id,
            name: record.subject.name,
            semester: record.subject.semester,
          },
        })),
      };
    });

    const classPresent = validClassAttendance.filter((record) => isPresent(record.status)).length;
    const classAbsent = validClassAttendance.filter((record) => isAbsent(record.status)).length;
    const eventPresent = eventAttendance.filter((record) => isPresent(record.status)).length;
    const eventAbsent = eventAttendance.filter((record) => isAbsent(record.status)).length;

    const overallPresent = classPresent + eventPresent;
    const overallAbsent = classAbsent + eventAbsent;
    const overallTotal = validClassAttendance.length + eventAttendance.length;

    return NextResponse.json({
      success: true,
      student,

      overall: {
        present: overallPresent,
        absent: overallAbsent,
        total: overallTotal,
        percentage: percentage(overallPresent, overallTotal),
      },

      subjects,
      subjectCount: subjects.length,
      subjectsWithRecords: subjects.filter((subject) => subject.total > 0).length,

      // Student sees ONLY their own event attendance.
      eventAttendance,
      eventStats: {
        present: eventPresent,
        absent: eventAbsent,
        total: eventAttendance.length,
        percentage: percentage(eventPresent, eventAttendance.length),
      },

      // Compatibility fields for the current student page.
      registeredSubjects: registrations.map((registration) => registration.subject),
      registrations,
      classAttendance: validClassAttendance,
      attendance: validClassAttendance,

      lastUpdated: new Date().toISOString(),
    });
  } catch (error) {
    console.error("STUDENT ATTENDANCE GET ERROR:", error);

    return NextResponse.json(
      {
        success: false,
        message: "Unable to load student attendance.",
        student: null,
        overall: { present: 0, absent: 0, total: 0, percentage: 0 },
        subjects: [],
        registeredSubjects: [],
        registrations: [],
        classAttendance: [],
        attendance: [],
        eventAttendance: [],
        eventStats: { present: 0, absent: 0, total: 0, percentage: 0 },
        subjectCount: 0,
        subjectsWithRecords: 0,
      },
      { status: 500 }
    );
  }
}