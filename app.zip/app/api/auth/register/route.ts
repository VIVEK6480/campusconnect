import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";

import { prisma } from "@/lib/prisma";

// ======================================================
// GET SUBJECTS FOR STUDENT REGISTRATION
// ======================================================

export async function GET() {
  try {
    const subjects = await prisma.subject.findMany({
      select: {
        id: true,
        name: true,
        semester: true,
      },
      orderBy: [
        {
          semester: "asc",
        },
        {
          name: "asc",
        },
      ],
    });

    return NextResponse.json(
      {
        success: true,
        subjects,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error(
      "REGISTER SUBJECTS GET ERROR:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        message: "Unable to load subjects.",
        subjects: [],
      },
      { status: 500 }
    );
  }
}

// ======================================================
// STUDENT ACCOUNT + ACADEMIC REGISTRATION
// ======================================================

export async function POST(request: Request) {
  try {
    const body: unknown = await request.json();

    // ==================================================
    // SAFELY READ REQUEST BODY
    // ==================================================

    const data =
      typeof body === "object" &&
      body !== null
        ? (body as Record<string, unknown>)
        : {};

    // ==================================================
    // READ BASIC INFORMATION
    // ==================================================

    const name =
      typeof data.name === "string"
        ? data.name.trim()
        : "";

    const email =
      typeof data.email === "string"
        ? data.email.trim().toLowerCase()
        : "";

    const password =
      typeof data.password === "string"
        ? data.password
        : "";

    // ==================================================
    // READ SEMESTER
    // ==================================================

    const semester = Number(
      data.semester
    );

    // ==================================================
    // READ SECTION
    // ==================================================

    const section =
      typeof data.section === "string"
        ? data.section.trim().toUpperCase()
        : "";

    // ==================================================
    // READ SUBJECT IDS
    //
    // IMPORTANT:
    // Explicitly make this string[] so Prisma never
    // receives unknown[].
    // ==================================================

    const rawSubjectIds =
      data.subjectIds;

    const subjectIds: string[] =
      Array.isArray(rawSubjectIds)
        ? rawSubjectIds.filter(
            (
              id: unknown
            ): id is string =>
              typeof id === "string" &&
              id.trim().length > 0
          ).map((id: string) =>
            id.trim()
          )
        : [];

    // ==================================================
    // BASIC VALIDATION
    // ==================================================

    if (!name || !email || !password) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Name, email and password are required.",
        },
        { status: 400 }
      );
    }

    // ==================================================
    // NAME VALIDATION
    // ==================================================

    if (name.length < 2) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Please enter a valid full name.",
        },
        { status: 400 }
      );
    }

    // ==================================================
    // EMAIL VALIDATION
    // ==================================================

    const emailRegex =
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(email)) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Please enter a valid email address.",
        },
        { status: 400 }
      );
    }

    // ==================================================
    // PASSWORD VALIDATION
    // ==================================================

    if (password.length < 8) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Password must contain at least 8 characters.",
        },
        { status: 400 }
      );
    }

    // ==================================================
    // SEMESTER VALIDATION
    // ==================================================

    if (
      !Number.isInteger(semester) ||
      semester < 1 ||
      semester > 8
    ) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Please select a valid semester.",
        },
        { status: 400 }
      );
    }

    // ==================================================
    // SECTION VALIDATION
    // ==================================================

    const allowedSections: string[] = [
      "A",
      "B",
      "C",
      "D",
    ];

    if (
      !allowedSections.includes(section)
    ) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Please select a valid section.",
        },
        { status: 400 }
      );
    }

    // ==================================================
    // SUBJECT VALIDATION
    // ==================================================

    if (subjectIds.length === 0) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Please select at least one subject.",
        },
        { status: 400 }
      );
    }

    // ==================================================
    // REMOVE DUPLICATE SUBJECT IDS
    //
    // Explicitly typed as string[] to avoid
    // TypeScript unknown[] errors.
    // ==================================================

    const uniqueSubjectIds: string[] =
      Array.from(
        new Set<string>(subjectIds)
      );

    // ==================================================
    // CHECK EXISTING USER
    // ==================================================

    const existingUser =
      await prisma.user.findUnique({
        where: {
          email,
        },
        select: {
          id: true,
        },
      });

    if (existingUser) {
      return NextResponse.json(
        {
          success: false,
          message:
            "An account with this email already exists.",
        },
        { status: 409 }
      );
    }

    // ==================================================
    // VERIFY SUBJECTS
    // ==================================================

    const selectedSubjects =
      await prisma.subject.findMany({
        where: {
          id: {
            in: uniqueSubjectIds,
          },
        },
        select: {
          id: true,
          name: true,
          semester: true,
        },
      });

    // ==================================================
    // CHECK ALL SUBJECT IDS ARE VALID
    // ==================================================

    if (
      selectedSubjects.length !==
      uniqueSubjectIds.length
    ) {
      return NextResponse.json(
        {
          success: false,
          message:
            "One or more selected subjects are invalid.",
        },
        { status: 400 }
      );
    }

    // ==================================================
    // CHECK SUBJECT SEMESTER
    // ==================================================

    const invalidSubject =
      selectedSubjects.some(
        (subject) =>
          subject.semester !== semester
      );

    if (invalidSubject) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Selected subjects must belong to the selected semester.",
        },
        { status: 400 }
      );
    }

    // ==================================================
    // HASH PASSWORD
    // ==================================================

    const hashedPassword =
      await bcrypt.hash(password, 10);

    // ==================================================
    // GENERATE CAMPUS USER ID
    // ==================================================

    async function generateCampusUserId(): Promise<string> {
      while (true) {
        const randomDigits =
          Math.floor(
            1000 +
              Math.random() * 9000
          );

        const campusUserId =
          `VKT-${randomDigits}`;

        const existingCampusUserId =
          await prisma.user.findUnique({
            where: {
              campusUserId,
            },
            select: {
              id: true,
            },
          });

        if (!existingCampusUserId) {
          return campusUserId;
        }
      }
    }

    const campusUserId =
      await generateCampusUserId();

    // ==================================================
    // DATABASE TRANSACTION
    //
    // IMPORTANT:
    // Increased timeout because registration can contain
    // many subjects and Neon database is being used.
    // ==================================================

    const result =
      await prisma.$transaction(
        async (tx) => {
          // --------------------------------------------
          // CREATE USER
          // --------------------------------------------

          const user =
            await tx.user.create({
              data: {
                name,
                email,
                password: hashedPassword,
                campusUserId,
                role: "STUDENT",
                approvalStatus: "PENDING",
              },
            });

          // --------------------------------------------
          // CREATE STUDENT REGISTRATIONS
          //
          // Create them one by one inside the same
          // transaction so Prisma does not keep many
          // concurrent queries open.
          // --------------------------------------------

          const registrations = [];

          for (
            const subjectId of uniqueSubjectIds
          ) {
            const registration =
              await tx.studentRegistration.create(
                {
                  data: {
                    // REQUIRED BY CURRENT PRISMA SCHEMA
                    id: crypto.randomUUID(),

                    studentId: user.id,

                    // Explicit string value
                    subjectId: subjectId,

                    semester,
                    section,

                    // REQUIRED BY CURRENT PRISMA SCHEMA
                    updatedAt: new Date(),
                  },
                }
              );

            registrations.push(
              registration
            );
          }

          // --------------------------------------------
          // CREATE ADMIN APPROVAL RECORD
          // --------------------------------------------

          const approval =
            await tx.userApproval.create({
              data: {
                userId: user.id,
                actionById: "PENDING",
                status: "PENDING",
              },
            });

          return {
            user,
            registrations,
            approval,
          };
        },
        {
          maxWait: 15000,
          timeout: 30000,
        }
      );

    // ==================================================
    // SUCCESS RESPONSE
    // ==================================================

    return NextResponse.json(
      {
        success: true,
        message:
          "Student registration submitted successfully. Waiting for approval.",
        data: {
          id: result.user.id,
          campusUserId:
            result.user.campusUserId,
          name: result.user.name,
          email: result.user.email,
          role: result.user.role,
          approvalStatus:
            result.user.approvalStatus,
          semester,
          section,
          subjectIds:
            uniqueSubjectIds,
          registrationCount:
            result.registrations.length,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error(
      "REGISTRATION ERROR:",
      error
    );

    // ==================================================
    // PRISMA UNIQUE CONSTRAINT ERROR
    // ==================================================

    if (
      error &&
      typeof error === "object" &&
      "code" in error &&
      error.code === "P2002"
    ) {
      return NextResponse.json(
        {
          success: false,
          message:
            "An account with the provided information already exists.",
        },
        { status: 409 }
      );
    }

    // ==================================================
    // GENERAL ERROR
    // ==================================================

    return NextResponse.json(
      {
        success: false,
        message:
          "Something went wrong while creating your account.",
      },
      { status: 500 }
    );
  }
}